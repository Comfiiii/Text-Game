#pragma once
#include "Item.h"

class BetterArmor : public Item
{
public:
	BetterArmor();
	~BetterArmor();
};

BetterArmor::BetterArmor()
{

}

BetterArmor::~BetterArmor()
{

}
