#pragma once
#include "Item.h"

class BetterSword : public Item
{
public:
	BetterSword();
	~BetterSword();

};

BetterSword::BetterSword()
{

}

BetterSword::~BetterSword()
{

}
