#include "Item.h"

void Item::Description() const
{
	std::cout << itemdescription;
}

void Item::Use()
{

}

Item::Item()
{

}

Item::~Item()
{

}
