#pragma once
#include "Item.h"

class Armor : public Item
{
public:
	Armor();
	~Armor();

};

Armor::Armor()
{

}

Armor::~Armor()
{

}
